package com.example.traderalert.mixin;

import com.example.traderalert.TraderOverlay;
import net.minecraft.class_310;
import net.minecraft.class_329;
import net.minecraft.class_332;
import org.spongepowered.asm.mixin.Final;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Shadow;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

@Mixin(class_329.class)
public class InGameHudMixin {
    @Shadow @Final private class_310 minecraft;

    @Inject(method = "render", at = @At("TAIL"))
    private void renderTraderOverlay(class_332 graphics, net.minecraft.class_9779 deltaTracker, CallbackInfo ci) {
        // Render permanent overlay
        TraderOverlay.renderOverlay(graphics, minecraft);
        
        // Render spawn notification
        TraderOverlay.renderSpawnNotification(graphics, minecraft);
    }
}