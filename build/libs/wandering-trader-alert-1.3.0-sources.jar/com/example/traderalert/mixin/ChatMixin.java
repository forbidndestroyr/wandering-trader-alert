package com.example.traderalert.mixin;

import com.example.traderalert.DebugCommand;
import net.minecraft.class_11908;
import net.minecraft.class_310;
import net.minecraft.class_342;
import net.minecraft.class_408;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Shadow;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfoReturnable;

@Mixin(class_408.class)
public class ChatMixin {
    
    @Shadow protected class_342 input;
    
    @Inject(method = "keyPressed", at = @At("HEAD"), cancellable = true)
    public void onKeyPressed(class_11908 keyEvent, CallbackInfoReturnable<Boolean> cir) {
        // Check if Enter key is pressed
        if (keyEvent.comp_4795() == 257 && this.input != null) { // GLFW_KEY_ENTER
            String message = this.input.method_1882().trim();
            
            // Intercept our debug command
            if (message.equalsIgnoreCase("/traderdebug") || message.equalsIgnoreCase("/trader debug")) {
                // Execute debug command client-side
                DebugCommand.executeDebugCommand(class_310.method_1551());
                
                // Clear the input and close chat
                this.input.method_1852("");
                class_310.method_1551().method_1507(null);
                
                // Cancel normal processing
                cir.setReturnValue(true);
            }
        }
    }
}
