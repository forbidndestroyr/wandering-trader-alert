package com.example.traderalert.mixin;

import com.example.traderalert.TraderSpawnTracker;
import net.minecraft.class_310;
import net.minecraft.class_638;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

@Mixin(class_310.class)
public class ClientLevelMixin {
    
    @Inject(method = "setLevel", at = @At("TAIL"))
    private void onWorldJoin(class_638 level, CallbackInfo ci) {
        if (level != null) {
            // Give the world a moment to fully load before checking for traders
            new Thread(() -> {
                try {
                    Thread.sleep(2000); // Wait 2 seconds for world to load
                    TraderSpawnTracker.onWorldJoin(class_310.method_1551());
                } catch (InterruptedException e) {
                    // Ignore
                }
            }).start();
        }
    }
}