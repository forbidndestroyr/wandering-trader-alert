package com.example.traderalert;

import net.minecraft.class_1297;
import net.minecraft.class_1299;
import net.minecraft.class_1937;
import net.minecraft.class_310;

public class TraderSpawnTracker {
    private static long lastTraderSpawnTime = -1;
    private static long worldStartTime = -1;
    private static boolean traderJustSpawned = false;
    private static long spawnNotificationTime = 0;
    private static class_1297 lastKnownTrader = null;
    private static int traderCount = 0;
    
    // Wandering trader spawn mechanics (vanilla values)
    private static final int MIN_SPAWN_DELAY = 24000; // 1 day (20 minutes)
    private static final int SPAWN_CHANCE_DELAY = 24000; // Check every day after min delay
    private static final double BASE_SPAWN_CHANCE = 0.075; // 7.5% base chance
    private static final double CHANCE_INCREMENT = 0.025; // 2.5% increase per failed attempt
    private static final double MAX_SPAWN_CHANCE = 0.075 + (0.025 * 3); // Cap at 15%
    
    public static void tick(class_310 client) {
        if (client.field_1687 == null) {
            worldStartTime = -1;
            return;
        }
        
        class_1937 world = client.field_1687;
        long currentTime = world.method_8532();
        
        // Initialize world start time
        if (worldStartTime == -1) {
            worldStartTime = currentTime;
            lastTraderSpawnTime = currentTime;
        }
        
        // Check for new trader spawn
        checkForNewTrader(client);
        
        // Update spawn notification timer
        if (traderJustSpawned && System.currentTimeMillis() - spawnNotificationTime > 3000) {
            traderJustSpawned = false;
        }
    }
    
    private static void checkForNewTrader(class_310 client) {
        if (client.field_1687 == null) return;
        
        // Find wandering trader
        class_1297 currentTrader = null;
        for (class_1297 entity : client.field_1687.method_18112()) {
            if (entity.method_5864() == class_1299.field_17713) {
                currentTrader = entity;
                break;
            }
        }
        
        // Check if a new trader spawned
        if (currentTrader != null && lastKnownTrader != currentTrader) {
            lastKnownTrader = currentTrader;
            lastTraderSpawnTime = client.field_1687.method_8532();
            traderJustSpawned = true;
            spawnNotificationTime = System.currentTimeMillis();
            traderCount++;
            
            // IMPORTANT: Reset spawn tracking when trader actually spawns
            // This ensures spawn chance resets to base value
            worldStartTime = client.field_1687.method_8532(); // Reset reference point
            System.out.println("[TraderAlert] NEW TRADER SPAWNED! Resetting spawn chance tracking.");
            
        } else if (currentTrader == null) {
            lastKnownTrader = null;
        }
    }
    
    public static int getTicksUntilSpawn(class_310 client) {
        if (client.field_1687 == null) {
            return MIN_SPAWN_DELAY;
        }
        
        // Try to get actual spawn data from world
        int actualTicksRemaining = getActualSpawnTimer(client);
        if (actualTicksRemaining >= 0) {
            return actualTicksRemaining;
        }
        
        // Fallback to our tracking
        if (lastTraderSpawnTime == -1) {
            lastTraderSpawnTime = client.field_1687.method_8532();
            return MIN_SPAWN_DELAY;
        }
        
        long currentTime = client.field_1687.method_8532();
        long timeSinceLastSpawn = currentTime - lastTraderSpawnTime;
        
        // If a trader exists, next spawn is after it despawns (typically 2-3 days)
        if (lastKnownTrader != null) {
            return MIN_SPAWN_DELAY * 2; // Approximate
        }
        
        // Calculate time until next spawn attempt
        if (timeSinceLastSpawn < MIN_SPAWN_DELAY) {
            return (int)(MIN_SPAWN_DELAY - timeSinceLastSpawn);
        }
        
        // After min delay, spawn attempts happen daily
        long daysSinceEligible = (timeSinceLastSpawn - MIN_SPAWN_DELAY) / SPAWN_CHANCE_DELAY;
        long ticksIntoCurrentDay = (timeSinceLastSpawn - MIN_SPAWN_DELAY) % SPAWN_CHANCE_DELAY;
        
        return (int)(SPAWN_CHANCE_DELAY - ticksIntoCurrentDay);
    }
    
    public static double getSpawnChance(class_310 client) {
        if (client.field_1687 == null) {
            return BASE_SPAWN_CHANCE;
        }
        
        // Try to get actual spawn chance from world
        double actualChance = getActualSpawnChance(client);
        if (actualChance >= 0) {
            return actualChance;
        }
        
        // Fallback to our calculation
        if (lastTraderSpawnTime == -1) {
            lastTraderSpawnTime = client.field_1687.method_8532();
            return BASE_SPAWN_CHANCE;
        }
        
        // If trader exists, chance is 0
        if (lastKnownTrader != null) {
            return 0.0;
        }
        
        long currentTime = client.field_1687.method_8532();
        long timeSinceLastSpawn = currentTime - lastTraderSpawnTime;
        
        if (timeSinceLastSpawn < MIN_SPAWN_DELAY) {
            return 0.0; // Not eligible yet
        }
        
        // Calculate current chance based on failed attempts
        long failedAttempts = (timeSinceLastSpawn - MIN_SPAWN_DELAY) / SPAWN_CHANCE_DELAY;
        double chance = BASE_SPAWN_CHANCE + (CHANCE_INCREMENT * failedAttempts);
        
        return Math.min(chance, MAX_SPAWN_CHANCE);
    }
    
    public static boolean shouldShowSpawnNotification() {
        return traderJustSpawned && ModConfig.isShowSpawnNotification();
    }
    
    // Try to access the actual world spawn timer
    private static int getActualSpawnTimer(class_310 client) {
        try {
            WorldSpawnDataReader.SpawnData data = WorldSpawnDataReader.getActualSpawnData(client);
            if (data != null) {
                return data.ticksUntilSpawn;
            }
        } catch (Exception e) {
            // Fall back on error
        }
        return -1; // Use fallback
    }
    
    // Try to access the actual world spawn chance
    private static double getActualSpawnChance(class_310 client) {
        try {
            WorldSpawnDataReader.SpawnData data = WorldSpawnDataReader.getActualSpawnData(client);
            if (data != null) {
                return data.spawnChance;
            }
        } catch (Exception e) {
            // Fall back on error
        }
        return -1; // Use fallback
    }
    
    // Enhanced tracking that persists world spawn state
    public static void onWorldJoin(class_310 client) {
        if (client.field_1687 == null) return;
        
        // Reset our tracking when joining a world
        lastTraderSpawnTime = -1;
        worldStartTime = -1;
        lastKnownTrader = null;
        traderJustSpawned = false;
        resetCount();
        
        // Try to detect existing traders to get a better baseline
        checkForExistingTraders(client);
    }
    
    private static void checkForExistingTraders(class_310 client) {
        if (client.field_1687 == null) return;
        
        // Look for existing wandering traders
        for (class_1297 entity : client.field_1687.method_18112()) {
            if (entity.method_5864() == class_1299.field_17713) {
                lastKnownTrader = entity;
                // If trader exists, assume recent spawn (conservative estimate)
                lastTraderSpawnTime = client.field_1687.method_8532() - 1000; // 1000 ticks ago
                break;
            }
        }
        
        // If no trader found, use current time as baseline
        if (lastKnownTrader == null) {
            lastTraderSpawnTime = client.field_1687.method_8532();
        }
    }
    
    public static String formatTicks(int ticks) {
        int seconds = ticks / 20;
        int minutes = seconds / 60;
        int hours = minutes / 60;
        int days = hours / 24;
        
        if (days > 0) {
            return String.format("%dd %dh %dm", days, hours % 24, minutes % 60);
        } else if (hours > 0) {
            return String.format("%dh %dm %ds", hours, minutes % 60, seconds % 60);
        } else if (minutes > 0) {
            return String.format("%dm %ds", minutes, seconds % 60);
        } else {
            return String.format("%ds", seconds);
        }
    }

    public static int getCount()
    {
        return traderCount;
    }

    public static void resetCount()
    {
        traderCount = 0;
    }
}
