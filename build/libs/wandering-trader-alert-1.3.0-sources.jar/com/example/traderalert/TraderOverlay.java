package com.example.traderalert;

import net.minecraft.class_310;
import net.minecraft.class_327;
import net.minecraft.class_332;

public class TraderOverlay {
    
    public static void renderOverlay(class_332 graphics, class_310 client) {
        if (!ModConfig.isOverlayMode()) return;
        
        class_327 font = client.field_1772;
        int screenWidth = client.method_22683().method_4486();
        int screenHeight = client.method_22683().method_4502();
        
        // Calculate trader info with fallbacks
        int ticksUntilSpawn = TraderSpawnTracker.getTicksUntilSpawn(client);
        double spawnChance = TraderSpawnTracker.getSpawnChance(client);
        
        // Ensure we have valid values
        if (ticksUntilSpawn < 0) ticksUntilSpawn = 24000; // Default to 1 day
        if (spawnChance < 0) spawnChance = 0.075; // Default to base chance
        
        // Format strings
        String timeString = "Next spawn: " + TraderSpawnTracker.formatTicks(ticksUntilSpawn);
        String chanceString = String.format("Spawn chance: %.1f%%", spawnChance * 100);
        
        // Debug: Always show some text to verify overlay is working
        if (client.field_1687 == null) {
            timeString = "Next spawn: No world";
            chanceString = "Spawn chance: 0.0%";
        }
        
        // Calculate positions (top-right corner with padding)
        int padding = 10;
        int lineHeight = font.field_2000 + 2;
        
        int timeWidth = font.method_1727(timeString);
        int chanceWidth = font.method_1727(chanceString);
        int maxWidth = Math.max(timeWidth, chanceWidth);
        
        int x = screenWidth - maxWidth - padding;
        int y = padding;

        // render traderCount 

        String traderCountStr = "Traders Spawned: " + TraderSpawnTracker.getCount();

        
        
        // Draw background
        int bgColor = 0x80000000; // Semi-transparent black
        graphics.method_25294(x - 4, y - 2, x + maxWidth + 4, y + lineHeight * 3 + 2, bgColor);
        
        // Draw text
        graphics.method_51433(font, timeString, x, y, 0xFFFFFFFF, true);
        graphics.method_51433(font, chanceString, x, y + lineHeight, 0xFFFFFFFF, true);
        graphics.method_51433(font, traderCountStr, x, y + lineHeight * 2, 0xFFFFFFFF, true);
    }
    
    public static void renderSpawnNotification(class_332 graphics, class_310 client) {
        if (!TraderSpawnTracker.shouldShowSpawnNotification()) return;
        
        class_327 font = client.field_1772;
        String message = "Wandering Trader Spawned";
        
        int screenWidth = client.method_22683().method_4486();
        int screenHeight = client.method_22683().method_4502();
        
        int textWidth = font.method_1727(message);
        int x = (screenWidth - textWidth) / 2;
        int y = screenHeight / 2 - 60; // Above center
        
        // Draw background
        int bgColor = 0x80000000; // Semi-transparent black
        graphics.method_25294(x - 10, y - 5, x + textWidth + 10, y + font.field_2000 + 5, bgColor);
        
        // Draw text with yellow color
        graphics.method_51433(font, message, x, y, 0xFFFFFF00, true);
    }
}
