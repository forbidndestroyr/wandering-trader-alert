package com.example.traderalert;

import net.fabricmc.api.ClientModInitializer;
import net.minecraft.class_1297;
import net.minecraft.class_238;
import net.minecraft.class_310;
import javax.sound.sampled.*;
import java.io.BufferedInputStream;
import java.io.InputStream;
import java.util.List;

public class WanderingTraderAlert implements ClientModInitializer {
    private static int tickCounter = 0;
    private static final int DING_INTERVAL = 40; // Ding every 2 seconds (40 ticks)
    private static boolean wasTraderNearby = false;
    private static Clip dingClip;
    private static WanderingTraderAlert instance;
    
    @Override
    public void onInitializeClient() {
        instance = this;
        // Load the sound file
        loadSound();
        
        // Register keybinds (would need Fabric API KeyBinding registry)
        // For now, keybinds are handled in tick event
    }
    
    private void loadSound() {
        try {
            // Load the ding sound from resources
            InputStream audioSrc = getClass().getResourceAsStream("/assets/traderalert/sounds/ding.wav");
            if (audioSrc == null) {
                System.err.println("[WanderingTraderAlert] Could not find ding.wav sound file");
                return;
            }
            
            InputStream bufferedIn = new BufferedInputStream(audioSrc);
            AudioInputStream audioStream = AudioSystem.getAudioInputStream(bufferedIn);
            
            dingClip = AudioSystem.getClip();
            dingClip.open(audioStream);
            
            // Set volume to a reasonable level
            FloatControl gainControl = (FloatControl) dingClip.getControl(FloatControl.Type.MASTER_GAIN);
            gainControl.setValue(-10.0f); // Reduce volume by 10 decibels
            
            audioStream.close();
            bufferedIn.close();
            
            System.out.println("[WanderingTraderAlert] Sound loaded successfully");
        } catch (Exception e) {
            System.err.println("[WanderingTraderAlert] Error loading sound: " + e.getMessage());
            e.printStackTrace();
        }
    }
    
    public static void onClientTick(class_310 client) {
        // Only run when in game and world is loaded
        if (client.field_1687 == null || client.field_1724 == null) {
            wasTraderNearby = false;
            tickCounter = 0;
            return;
        }
        
        // Update trader spawn tracker
        TraderSpawnTracker.tick(client);
        
        // Handle key inputs
        KeyBinds.handleKeyInputs();
        
        // Check for wandering traders within render distance
        boolean traderNearby = isWanderingTraderNearby(client);
        
        if (traderNearby) {
            // If trader just appeared, reset counter to play sound immediately
            if (!wasTraderNearby) {
                tickCounter = DING_INTERVAL;
            }
            
            tickCounter++;
            
            // Play ding sound at intervals (if enabled)
            if (tickCounter >= DING_INTERVAL && ModConfig.isSoundEnabled()) {
                playDingSound(client);
                tickCounter = 0;
            }
        } else {
            tickCounter = 0;
        }
        
        wasTraderNearby = traderNearby;
    }
    
    private static boolean isWanderingTraderNearby(class_310 client) {
        if (client.field_1724 == null || client.field_1687 == null) {
            return false;
        }
        
        // Get render distance in blocks
        int renderDistance = client.field_1690.method_42503().method_41753() * 16;
        
        // Create a bounding box around the player based on render distance
        class_238 searchBox = new class_238(
            client.field_1724.method_23317() - renderDistance,
            client.field_1724.method_23318() - renderDistance,
            client.field_1724.method_23321() - renderDistance,
            client.field_1724.method_23317() + renderDistance,
            client.field_1724.method_23318() + renderDistance,
            client.field_1724.method_23321() + renderDistance
        );
        
        // Find all entities and filter for wandering traders
        List<class_1297> entities = client.field_1687.method_8333(
            (class_1297) null,
            searchBox,
            entity -> entity != null && entity.method_5864().toString().contains("wandering_trader")
        );
        
        // Check if any traders are within actual render distance
        for (class_1297 trader : entities) {
            double distance = client.field_1724.method_5739(trader);
            if (distance <= renderDistance) {
                return true;
            }
        }
        
        return false;
    }
    
    private static void playDingSound(class_310 client) {
        if (dingClip != null) {
            // Stop the clip if it's still playing and rewind it
            if (dingClip.isRunning()) {
                dingClip.stop();
            }
            dingClip.setFramePosition(0);
            dingClip.start();
        }
    }
}